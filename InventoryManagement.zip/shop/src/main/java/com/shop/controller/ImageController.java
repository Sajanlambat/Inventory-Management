package com.shop.controller;

import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ImageController {

    // Define your imagesDirectory here

    @PostMapping("/api/get/images")
    public ResponseEntity<String> uploadImage(@RequestParam("file") MultipartFile file) {
        try {
            // Logic to save the file to the imagesDirectory
            // You can use file.transferTo(new File(imagesDirectory + "/" + file.getOriginalFilename())) or other methods
            return ResponseEntity.ok("Image uploaded successfully");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Failed to upload image");
        }
    }

    // Define your getImage method here
    
    @GetMapping("/api/fetch/images")
    public List<String> fetchImages() {
        String directoryPath = "D:/ReactProject/first-project/reactproject/public/images";
        List<String> imagePaths = ImageFetcher.fetchImages(directoryPath);

        // Extract file names from the file paths
        List<String> imageNames = new ArrayList<>();
        for (String path : imagePaths) {
            String fileName = Paths.get(path).getFileName().toString();
            imageNames.add("/images/"+fileName);
        }

        return imageNames;
    }



}
