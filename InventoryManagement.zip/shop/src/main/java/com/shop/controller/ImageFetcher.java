package com.shop.controller;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class ImageFetcher {

    public static List<String> fetchImages(String directoryPath) {
        List<String> imagePaths = new ArrayList<>();

        try {
            Path directory = Paths.get(directoryPath);

            // Traverse the directory and collect paths of image files
            Files.walk(directory)
                    .filter(Files::isRegularFile)
                    .filter(path -> isImageFile(path))
                    .forEach(path -> imagePaths.add(path.toString()));
        } catch (IOException e) {
            e.printStackTrace(); // Handle IOException appropriately
        }

        return imagePaths;
    }

    private static boolean isImageFile(Path path) {
        String fileName = path.getFileName().toString().toLowerCase();
        return fileName.endsWith(".jpg") || fileName.endsWith(".jpeg") ||
               fileName.endsWith(".png") || fileName.endsWith(".gif") ||
               fileName.endsWith(".bmp");
    }

    public static void main(String[] args) {
        String directoryPath = "D:/ReactProject/first-project/reactproject/public/images";
        List<String> imagePaths = fetchImages(directoryPath);

        // Print the paths of all images
        for (String imagePath : imagePaths) {
            System.out.println(imagePath);
        }
    }
}
